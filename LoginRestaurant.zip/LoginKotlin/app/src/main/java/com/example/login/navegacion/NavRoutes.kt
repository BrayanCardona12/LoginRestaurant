package com.example.login.navegacion

sealed class NavRoutes(val route:String) {
    object Factura: NavRoutes(route = "p5")
    object Menu: NavRoutes(route = "p4")
    object homeMenu: NavRoutes(route = "p3")
    object irREgistr : NavRoutes(route = "p2")
    object home : NavRoutes(route = "p1")
}
