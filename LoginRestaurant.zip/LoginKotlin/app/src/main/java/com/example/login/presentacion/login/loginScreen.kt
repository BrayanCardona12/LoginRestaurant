package com.example.login.presentacion.login

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.navigation.NavController
import com.example.login.R
import com.example.login.navegacion.NavRoutes
import com.example.login.presentacion.login.compons.BotonRounded
import com.example.login.presentacion.login.compons.TransTextFile

@Composable
fun LoginScreen(navController: NavController) {
    val emailvalue = rememberSaveable { mutableStateOf("") }
    val passwordvalue = rememberSaveable { mutableStateOf("") }
    var passwordvisibilit by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)

    ) {

        Image(
            modifier = Modifier
                .width(400.dp)
                .height(350.dp),
            painter = painterResource(id = R.drawable.paisajed),
            contentDescription = null,
            contentScale = ContentScale.FillBounds

        )
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.BottomCenter
        ) {
            ConstraintLayout() {
                val (surface, fab) = createRefs()
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .constrainAs(surface) {
                            bottom.linkTo(parent.bottom)
                        }
                        .height(400.dp), color = Color.White,
                    shape = RoundedCornerShape(topStartPercent = 8, topEndPercent = 8)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Bienvendo", style = MaterialTheme.typography.h4.copy(
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Text(
                            text = "Accede a tu cuenta",
                            style = MaterialTheme.typography.h5.copy(
                                color = MaterialTheme.colors.primary,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TransTextFile(
                                textFieldValue = emailvalue,
                                textLabel = "Email",
                                keyboardType = KeyboardType.Email,
                                keyboardActions = KeyboardActions(
                                    onNext = {
                                        focusManager.moveFocus(
                                            focusDirection = FocusDirection.Down
                                        )
                                    }
                                ),
                                imeAction = ImeAction.Next
                            )
                            TransTextFile(
                                textFieldValue = passwordvalue,
                                textLabel = "Contraseña",
                                keyboardType = KeyboardType.Password,
                                keyboardActions = KeyboardActions(
                                    onNext = {
                                        focusManager.clearFocus(
                                            //TODO{}
                                        )
                                    }
                                ),
                                imeAction = ImeAction.Done,
                                trailingIcon = {
                                    IconButton(onClick = {
                                        passwordvisibilit = !passwordvisibilit
                                    } // Fin del Onclick
                                    ) {
                                        Icon(
                                            imageVector = if (passwordvisibilit) {
                                                Icons.Default.Visibility
                                            } else {
                                                Icons.Default.VisibilityOff
                                            },
                                            contentDescription = "Toggle"
                                        )
                                    }
                                }, // fin del trailingIcon
                                visualTransformation = if (passwordvisibilit) {
                                    VisualTransformation.None
                                } else {
                                    PasswordVisualTransformation()
                                }
                            ) // Fin TextFile Password
                            Text(
                                modifier = Modifier.fillMaxWidth(),
                                text = "Olvido Contraseña",
                                style = MaterialTheme.typography.body1,
                                textAlign = TextAlign.End
                            ) // Fin del Text
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                BotonRounded(
                                    text = "Login",
                                    displayProgressBar = false,
                                    onClick = {
                                        navController.navigate(route = NavRoutes.homeMenu.route)
                                    }
                                )  // fin del BotonRounded
                                ClickableText(
                                    onClick = {navController.navigate(route = NavRoutes.irREgistr.route)},

                                    text = buildAnnotatedString {
                                        append("¿No tiene cuenta activa?")
                                        withStyle(
                                            style = SpanStyle(
                                                color = MaterialTheme.colors.primary,
                                                fontWeight = FontWeight.Bold
                                            ) //Fin del SpanStyle
                                        ) {
                                            append(" Registrate")
                                        }
                                    }
                                    // Fin del Texto
                                )



                            }// Fin de la columna de botones
                        } // fin e columInterna


                    }// fin de la columna externa

                }
                FloatingActionButton(
                    modifier = Modifier
                        .size(72.dp)
                        .constrainAs(fab) {
                            top.linkTo(surface.top, margin = (-36).dp)
                            end.linkTo(surface.end, margin = 36.dp)
                        }
                        .background(Color.Transparent),
                    onClick = { /*TODO*/ }) {
                    Icon(
                        modifier = Modifier
                            .size(72.dp),
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "",
                        tint = Color.White
                    )
                }
            }


        }
    } // Fin del box principal
} // Fin de la funcion

