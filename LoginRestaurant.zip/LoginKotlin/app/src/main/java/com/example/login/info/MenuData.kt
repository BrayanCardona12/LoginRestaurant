package com.example.login.info

data class MenuData(
    var foto: Int,
    var nom:String,
    var descri:String
)
