package com.example.login.navegacion

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.login.presentacion.login.LoginScreen
import com.example.login.presentacion.login.registro.PantallaRegist
import com.example.login.screensmenu.Pantalla1
import com.example.login.screensmenu.Pantalla2
import com.example.login.screensmenu.Pantalla3

@Composable
fun Navegacioon(){
    var contr = rememberNavController()
    NavHost(navController = contr , startDestination = NavRoutes.home.route ) {
        composable(route = NavRoutes.irREgistr.route) { PantallaRegist(contr) }
        composable(route = NavRoutes.home.route) { LoginScreen(contr) }
        composable(route = NavRoutes.homeMenu.route) { Pantalla1(contr) }
        composable(route = NavRoutes.Menu.route) { Pantalla2(contr) }
        composable(route = NavRoutes.Factura.route) { Pantalla3(contr) }

    }
}