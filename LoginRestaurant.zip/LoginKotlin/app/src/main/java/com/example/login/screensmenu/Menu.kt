package com.example.login.screensmenu

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.login.R
import com.example.login.info.menuInfo
import com.example.login.navegacion.NavRoutes

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Pantalla2(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(backgroundColor = Color.DarkGray, modifier = Modifier.height(100.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    Image(painter = painterResource(id = R.drawable.rest), contentDescription = "", modifier = Modifier
                        .clip(CircleShape)
                        .border(5.dp, Color.LightGray, CircleShape))
                    Text(text = "Restaurante", style = TextStyle(Color.LightGray, fontWeight = FontWeight.Bold, fontSize = 35.sp))
                    Image(painter = painterResource(id = R.drawable.newspaper), contentDescription = "", modifier = Modifier
                        .size(75.dp)
                        .clickable { navController.navigate(NavRoutes.Factura.route) })
                }

            }
        }
    ) {
        Contpantalla2(navController)
    }
}

@Composable
fun Contpantalla2(navController: NavController) {
    LazyColumn(
        modifier = Modifier
            .background(Color.Gray)
            .padding(10.dp)
            .fillMaxSize()
    ) {

        items(menuInfo) {
                s -> Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center) {
            var estado by rememberSaveable { mutableStateOf(false) }
            Image(painter = painterResource(id = s.foto), contentDescription = "", modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .border(3.dp, Color.LightGray, CircleShape))
            Column(modifier = Modifier.clickable { estado = !estado }) {
                Text(text = s.nom, style =  TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                Text(text = "Características", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                Text(text = s.descri, style = TextStyle(textAlign = TextAlign.Justify),modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ) ,maxLines = if (estado) Int.MAX_VALUE else 2)
            }
        }
            Spacer(modifier = Modifier.height(10.dp))

        }

    }
}